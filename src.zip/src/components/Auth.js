import { useDispatch } from 'react-redux'
import styled from 'styled-components'
import { authActions } from '../Store/auth'
const Styles = styled.div`
	width: 800px;
	height: auto;
	margin: 0 auto;
	display: flex;
`
const Img = styled.img`
	width: 150px;
	height: 50px;
`
const Input = styled.input`
	width: 300px;
	height: 50px;
	/* border: 5px; */
	margin: top;
	margin: 1rem auto;
	border-radius: 5px;
`
const Form = styled.form`
	margin: 0 auto;
`
const Button = styled.button`
	width: 300px;
	height: 55px;
	background-color: green;
    border-radius: 5px;
`
const Container = styled.div`
	width: 400px;
	height: 400px;
	padding: 20px;
	display: flex;
	justify-content: center;
	flex-direction: column;
	align-items: center;
	background: white;
	box-shadow: 1px 1px 10px black;
`

const Auth = () => {
    const dispatch = useDispatch()

	const loginHandler =(e)=>{
		e.preventDefault()
		dispatch(authActions.login())
		}
	  
	return (
		<Styles>
			<Form>
				<Img src='https://upload.wikimedia.org/wikipedia/en/thumb/8/8c/Trello_logo.svg/1200px-Trello_logo.svg.png' />
				<Container>
					<h2>вход в trello</h2>
					<div>
						<Input
							type="email"
							placeholder='Укажите адресс электронной почты'
							id='email'
						/>
					</div>
					<div>
						<Input type='password' placeholder='Введите пароль' id='password'/>
					</div>
					<Button onClick={loginHandler}>Войти</Button>
				</Container>
			</Form>
		</Styles>
	)
}
export default Auth
