import { useDispatch, useSelector } from 'react-redux'
import Styled from 'styled-components'

const Container = Styled.header`
  width: 1500px;
  height: 3rem;
  display: flex;
  /* justify-content:space-between;/ */
  background-color: gray;
  color: white;
  padding: 0 10%;
`
const Img = Styled.img`
 width: 150px;
 height: 50px;
 `
const Li = Styled.li`
  margin: 0 1rem;
  color: white;
  border: none;
 `
const Ul = Styled.ul`
 display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
  align-items: center;

`
const Button = Styled.button`
width: 100px;
height: 40px;
 background-color: gray;
 border-radius:4px;
`

const Input = Styled.input`
width: 200px;
height: 30px;
border-radius:5px;
margin-left:300px
`

const Header = () => {
	const isAuth = useSelector((state) => state.auth.isAuthenticated)

	// const logoutHandler = (e) => {
	// 	e.preventDefault()
	// 	dispatch(authActions.logout())
	// }

	return (
		<>
		<Container>
			<Img src='https://upload.wikimedia.org/wikipedia/en/thumb/8/8c/Trello_logo.svg/1200px-Trello_logo.svg.png' />{' '}
			<Ul>
				<Li>Рабочие пространства</Li>
				<Li>Недавние</Li>
				<Li>В избранном</Li>
				<Li>Шаблоны</Li>
				<Li>
					<Button>Создать</Button>
				</Li>
			</Ul>
			<Input placeholder='search' />
		</Container>
		<div>
		 <p>+Добавит еще одну колонку</p>
		</div>
		</>
		
	)
}
export default Header
