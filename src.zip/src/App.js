
import './App.css';
import Auth from './components/Auth';
import Header from './components/Header';
import { useSelector } from 'react-redux';


function App() {
  const isAuth = useSelector((state) => state.auth.isAuthenticated)


  return (
    <div className="App">
      { isAuth ? <Header/>: <Auth/>}
    </div>
  );
}

export default App;
