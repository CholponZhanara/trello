import { createSlice } from "@reduxjs/toolkit";

const AddSlice = createSlice({
    name:'add',
    initialState:[],
    reducers:{
        add(state,action){
       state.push({
           task:action.payload.task,
           id:action.payload.id,
           todo:[]
       })
        }
    }
})
export const addAction = AddSlice.actions
export default AddSlice