import { createSlice } from '@reduxjs/toolkit'

const initToggleState = { showToggle: false }

const toggleSlice = createSlice({
	name: 'toggle',
	initialState: initToggleState,
	reducers: {
		change(state) {
			state.showToggle = false
		},
		toogle(state) {
			state.showToggle = true
		},
	},
})
export const toggleActions = toggleSlice.actions
export default toggleSlice
