import Header from './Header'
import styled from 'styled-components'
import { useDispatch, useSelector } from 'react-redux'
import { toggleActions } from '../Store/toggle'
import { addAction } from '../Store/add'
import { useState } from 'react'

const Div = styled.div`
	width: 300px;
	height: 50px;
	background-color:opocity;
`
const P = styled.p`
	color: white;
`
const Input = styled.input`
height: 30px;
width:250px ;
`
const Button = styled.button`
    margin: 10px;
    background-color: #0079BF;
	margin-right:113px;
    border: none;
    color: #fff;
    height: 25px;
    border-radius: 4px
`

const Todo = () => {
	const [value, setValue] = useState('')
	const toogle = useSelector((state) => state.toogle.showToggle)
	// console.log(toogle)
	const dispatch = useDispatch()
      
	const  onChangeValue= (e)=>{
		setValue(e.target.value)
	}
	console.log(value);

	const toogleHandler = (e) => {
		dispatch(toggleActions.toogle())
	}
	const addHandler = () => {
		dispatch(addAction.add({
			task:value,
			id:Math.random().toString()

		}))
	}

	return (
		<>
		<Header />
			<Div>
				
				{!toogle ? (
					<P onClick={toogleHandler}>+Добавить еще одну колонку</P>
				) : (
					<div>
						<Input placeholder='Ввести заголовок списка' 
						onChange={onChangeValue}/>
						<Button onClick={addHandler}>Добавить список</Button>
						<button
							onClick={() => dispatch(toggleActions.change())}
						>
							X
						</button>
					</div>
				)}
			</Div>
		</>
	)
}
export default Todo
