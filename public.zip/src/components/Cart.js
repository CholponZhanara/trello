import styled from 'styled-components'

const Styles = styled.div`
	width: 200px;
	height: 120px;
	background-color:white;
    margin-top: 100px;
`

const Cart = (props)=>{
return(
    <Styles>
    <p>{props.task}</p>
    <textarea placeholder="Ввести заголовок для этой карточки"/>
    <button>Добавить карточку</button>
    <button>X</button>
    
    </Styles>
)


}
export default Cart