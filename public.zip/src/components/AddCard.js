import React from 'react'
import { useSelector } from 'react-redux'
import Cart from './Cart';

export const AddCard = () => {
    const tasks = useSelector((state)=> state.add)
    console.log(tasks);
  return (
   <div>
{tasks.map((el)=>(
  <Cart key={el.id} task={el.task} id={el.id}/>
))}
   </div>
  )
}



