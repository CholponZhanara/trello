import './App.css'
import Auth from './components/Auth'
import { useSelector } from 'react-redux'
import Todo from './components/Todo'
import { AddCard } from './components/AddCard'

function App() {
	const isAuth = useSelector((state) => state.auth.isAuthenticated)

	return <div className='App'>{isAuth ? <Todo /> : <Auth />}
  <AddCard/></div>
}

export default App
